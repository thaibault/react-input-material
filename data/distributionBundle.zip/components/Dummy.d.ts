import { FunctionComponent } from 'react';
import { DummyProps } from '../type';
/**
 * Generic strict wrapper component.
 * @param properties - Given component properties.
 * @param _reference - Given reference to mutable persistent object.
 *
 * @returns React elements.
 */
export declare const Dummy: FunctionComponent<DummyProps> & {
    isDummy: true;
};
export declare const CodeEditor: FunctionComponent<DummyProps> & {
    isDummy: true;
};
export declare const Editor: FunctionComponent<DummyProps> & {
    isDummy: true;
};
export declare const RichTextEditor: FunctionComponent<DummyProps> & {
    isDummy: true;
};
export declare const TextEditor: FunctionComponent<DummyProps> & {
    isDummy: true;
};
export default Dummy;
