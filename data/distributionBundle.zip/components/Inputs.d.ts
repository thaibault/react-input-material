import { Mapping } from 'clientnode/type';
import { ForwardedRef, ReactElement } from 'react';
import { InputProps, InputsAdapter as Adapter, InputsComponent, InputsPropertiesItem, InputsProps } from '../type';
/**
 * Generic inputs wrapper component.
 * @property static:displayName - Descriptive name for component to show in web
 * developer tools.
 * @param props - Given components properties.
 * @param reference - Reference object to forward internal state.
 *
 * @returns React elements.
 */
export declare const InputsInner: {
    <T = unknown, P extends InputsPropertiesItem<T, unknown> = InputProps<T>, State = Mapping<unknown>>(props: InputsProps<T, P>, reference?: ForwardedRef<Adapter<T, P>> | undefined): ReactElement;
    displayName: string;
};
/**
 * Wrapping web component compatible react component.
 * @property static:defaultProperties - Initial property configuration.
 * @property static:propTypes - Triggers reacts runtime property value checks.
 * @property static:strict - Indicates whether we should wrap render output in
 * reacts strict component.
 * @property static:wrapped - Wrapped component.
 *
 * @param props - Given components properties.
 * @param reference - Reference object to forward internal state.
 *
 * @returns React elements.
 */
export declare const Inputs: InputsComponent;
export default Inputs;
