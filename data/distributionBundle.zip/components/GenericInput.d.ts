import { ForwardedRef, KeyboardEvent as ReactKeyboardEvent, ReactElement } from 'react';
import { DefaultInputProperties as DefaultProperties, InputAdapter as Adapter, InputModelState as ModelState, InputProps as Props, GenericInputComponent, TinyMCEOptions } from '../type';
export declare const ACEEditorOptions: {
    basePath: string;
    useWorker: boolean;
};
export declare const TINYMCE_DEFAULT_OPTIONS: Partial<TinyMCEOptions>;
/**
 * Derives validation state from provided properties and state.
 * @param properties - Current component properties.
 * @param currentState - Current component state.
 *
 * @returns Whether component is in an aggregated valid or invalid state.
 */
export declare function determineValidationState<T>(properties: DefaultProperties<T>, currentState: Partial<ModelState>): boolean;
/**
 * Avoid propagating the enter key event since this usually sends a form which
 * is not intended when working in a text field.
 * @param event - Keyboard event.
 *
 * @returns Nothing.
 */
export declare function preventEnterKeyPropagation(event: ReactKeyboardEvent): void;
/**
 * Indicates whether a provided query is matching currently provided
 * suggestion.
 * @param suggestion - Candidate to match again.
 * @param query - Search query to check for matching.
 *
 * @returns Boolean result whether provided suggestion matches given query or
 * not.
 */
export declare function suggestionMatches(suggestion: string, query?: null | string): boolean;
/**
 * Generic input wrapper component which automatically determines a useful
 * input field depending on given model specification.
 *
 * Dataflow:
 *
 * 1. On-Render all states are merged with given properties into a normalized
 *    property object.
 * 2. Properties, corresponding state values and sub node instances are saved
 *    into a "ref" object (to make them accessible from the outside e.g. for
 *    wrapper like web-components).
 * 3. Event handler saves corresponding data modifications into state and
 *    normalized properties object.
 * 4. All state changes except selection changes trigger an "onChange" event
 *    which delivers the consolidated properties object (with latest
 *    modifications included).
 * @property static:displayName - Descriptive name for component to show in web
 * developer tools.
 *
 * @param props - Given components properties.
 * @param reference - Reference object to forward internal state.
 *
 * @returns React elements.
 */
export declare const GenericInputInner: {
    <Type = unknown>(props: Props<Type>, reference?: ForwardedRef<Adapter<Type>> | undefined): ReactElement;
    displayName: string;
};
/**
 * Wrapping web component compatible react component.
 * @property static:defaultModelState - Initial model state.
 * @property static:defaultProperties - Initial property configuration.
 * @property static:locales - Defines input formatting locales.
 * @property static:propTypes - Triggers reacts runtime property value checks.
 * @property static:strict - Indicates whether we should wrap render output in
 * reacts strict component.
 * @property static:transformer - Generic input data transformation
 * specifications.
 * @property static:wrapped - Wrapped component.
 *
 * @param props - Given components properties.
 * @param reference - Reference object to forward internal state.
 *
 * @returns React elements.
 */
export declare const GenericInput: GenericInputComponent;
export default GenericInput;
