import { ForwardedRef, ReactElement } from 'react';
import { IntervalAdapter as Adapter, IntervalComponent, IntervalProps as Props } from '../type';
/**
 * Generic interval start, end input wrapper component.
 * @param props - Component properties.
 * @param reference - Mutable reference bound to created component instance.
 *
 * @returns React elements.
 */
export declare const IntervalInner: {
    (props: Props, reference?: ForwardedRef<Adapter> | undefined): ReactElement;
    displayName: string;
};
/**
 * Wrapping web component compatible react component.
 * @property static:defaultProperties - Initial property configuration.
 * @property static:propTypes - Triggers reacts runtime property value checks.
 * @property static:strict - Indicates whether we should wrap render output in
 * reacts strict component.
 * @property static:wrapped - Wrapped component.
 *
 * @param props - Given components properties.
 * @param reference - Reference object to forward internal state.
 *
 * @returns React elements.
 */
export declare const Interval: IntervalComponent;
export default Interval;
