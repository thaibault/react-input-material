import { ForwardedRef, ReactElement } from 'react';
import { DefaultFileInputProperties as DefaultProperties, FileInputAdapter as Adapter, FileInputModelState as ModelState, FileInputProperties as Properties, FileInputProps as Props, FileRepresentationType as RepresentationType, FileInputComponent } from '../type';
export declare const preserveStaticFileBaseNameInputGenerator: Properties['generateFileNameInputProperties'];
/**
 * Determines which type of file we have to present.
 * @param contentType - File type to derive representation type from.
 * @returns Nothing.
 */
export declare const determineRepresentationType: (contentType: string) => RepresentationType;
export declare const determineValidationState: <P extends DefaultProperties>(properties: P, invalidName: boolean, currentState: ModelState) => boolean;
export declare const readBinaryDataIntoText: (blob: Blob, encoding?: string) => Promise<string>;
/**
 * Validateable checkbox wrapper component.
 * @property static:displayName - Descriptive name for component to show in web
 * developer tools.
 *
 * Dataflow:
 *
 * 1. On-Render all states are merged with given properties into a normalized
 *    property object.
 * 2. Properties, corresponding state values and sub node instances are saved
 *    into a "ref" object (to make them accessible from the outside e.g. for
 *    wrapper like web-components).
 * 3. Event handler saves corresponding data modifications into state and
 *    normalized properties object.
 * 4. All state changes except selection changes trigger an "onChange" event
 *    which delivers the consolidated properties object (with latest
 *    modifications included).
 *
 * @property static:displayName - Descriptive name for component to show in web
 * developer tools.
 *
 * @param props - Given components properties.
 * @param reference - Reference object to forward internal state.
 *
 * @returns React elements.
 */
export declare const FileInputInner: {
    (props: Props, reference?: ForwardedRef<Adapter> | undefined): ReactElement;
    displayName: string;
};
/**
 * Wrapping web component compatible react component.
 * @property static:defaultModelState - Initial model state.
 * @property static:defaultProperties - Initial property configuration.
 * @property static:propTypes - Triggers reacts runtime property value checks.
 * @property static:strict - Indicates whether we should wrap render output in
 * reacts strict component.
 * @property static:wrapped - Wrapped component.
 *
 * @param props - Given components properties.
 * @param reference - Reference object to forward internal state.
 *
 * @returns React elements.
 */
export declare const FileInput: FileInputComponent;
export default FileInput;
