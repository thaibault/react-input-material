import { FunctionComponent } from 'react';
import { TransitionProps } from 'react-transition-group/Transition';
/**
 * Generic animation wrapper component.
 * @param properties - Component given properties object.
 *
 * @returns React elements.
 */
export declare const GenericAnimate: FunctionComponent<Partial<TransitionProps<HTMLElement | undefined>>>;
export default GenericAnimate;
