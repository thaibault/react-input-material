import { FunctionComponent, ReactElement } from 'react';
import { Properties } from '../type';
/**
  * Wraps given component with a tooltip component with given tooltip
  * configuration.
  * @param properties - Component provided properties.
  * @param properties.children - Component or string to wrap.
  * @param properties.options - Tooltip options.
  *
  * @returns Wrapped given content.
 */
export declare const WrapTooltip: FunctionComponent<{
    children: ReactElement;
    options?: Properties['tooltip'];
}>;
export default WrapTooltip;
