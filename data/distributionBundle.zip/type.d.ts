import PropertyTypes from 'clientnode/property-types';
import { Mapping, PlainObject, RecursivePartial, ValueOf } from 'clientnode/type';
import { ComponentClass, FocusEvent, ForwardRefExoticComponent, FunctionComponent, HTMLProps, KeyboardEvent, MouseEvent, MutableRefObject, ReactElement, RefAttributes, Requireable, SyntheticEvent } from 'react';
import CodeEditorType, { IAceEditorProps as CodeEditorProps } from 'react-ace';
import { EditorOptions as RawTinyMCEOptions, Editor as RichTextEditor } from 'tinymce';
import { ComponentAdapter, PropertiesValidationMap, StaticWebComponent as StaticBaseWebComponent, ValidationMapping } from 'web-component-wrapper/type';
import { MDCMenuFoundation } from '@material/menu';
import { MDCSelectFoundation } from '@material/select';
import { MDCTextFieldFoundation } from '@material/textfield';
import { CardMediaProps } from '@rmwc/card';
import { MenuApi } from '@rmwc/menu';
import { SelectProps } from '@rmwc/select';
import { TextFieldProps } from '@rmwc/textfield';
import { ThemeProviderProps } from '@rmwc/theme';
import { TooltipProps } from '@rmwc/tooltip';
import { IconOptions, RipplePropT } from '@rmwc/types';
import { Editor as RichTextEditorComponent, IAllProps as RichTextEditorProps } from '@tinymce/tinymce-react';
export declare type DummyProps = Mapping<unknown> & {
    children?: ReactElement;
};
export interface GenericEvent<T = unknown> extends SyntheticEvent {
    detail?: T;
}
export interface TestEnvironment {
    container: HTMLDivElement | null;
    render: <T = HTMLElement>(_component: ReactElement) => null | T;
}
export interface CursorState {
    end: number;
    start: number;
}
export declare type Renderable = Array<ReactElement | string> | ReactElement | string;
export interface CommonBaseModel {
    declaration: string;
    default: unknown;
    description: string;
    emptyEqualsNull: boolean;
    maximum: number | string;
    maximumLength: number;
    minimum: number | string;
    minimumLength: number;
    name: string;
    selection?: SelectProps['options'];
    trim: boolean;
    type: string;
    value?: unknown;
}
export interface ModelState {
    dirty: boolean;
    focused: boolean;
    invalid: boolean;
    invalidRequired: boolean;
    pristine: boolean;
    touched: boolean;
    untouched: boolean;
    valid: boolean;
    visited: boolean;
}
export interface BaseModel extends CommonBaseModel {
    invertedRegularExpressionPattern: Array<RegExp | string> | null | RegExp | string;
    mutable: boolean;
    nullable: boolean;
    regularExpressionPattern: Array<RegExp | string> | null | RegExp | string;
    state: ModelState;
    writable: boolean;
}
export interface CommonModel<T = unknown> extends CommonBaseModel {
    default: null | T;
    value?: null | T;
}
export interface Model<T = unknown> extends BaseModel {
    default: null | T;
    value?: null | T;
}
export interface BaseProperties extends CommonBaseModel, ModelState {
    className: string;
    disabled: boolean;
    enforceUncontrolled: boolean;
    id: string;
    initialValue: unknown;
    invertedPattern: Array<RegExp | string> | null | RegExp | string;
    label: string;
    model: BaseModel;
    name: string;
    pattern: Array<RegExp | string> | null | RegExp | string;
    required: boolean;
    requiredText: string;
    ripple: RipplePropT;
    rootProps: HTMLProps<Mapping<unknown>>;
    showDeclaration: boolean;
    showInitialValidationState: boolean;
    styles: Mapping;
    themeConfiguration: ThemeProviderProps['options'];
    tooltip: string | TooltipProps;
}
export declare type BaseProps = Partial<Omit<BaseProperties, 'model'>> & {
    model?: Partial<BaseModel>;
};
export declare type DefaultBaseProperties = Omit<BaseProps, 'model'> & {
    model: BaseModel;
};
export interface TypedProperties<T = unknown> extends BaseProperties {
    initialValue: null | T;
    model: Model<T>;
    onBlur: (_event: GenericEvent | undefined, _properties: this) => void;
    onChange: (_properties: this, _event?: GenericEvent) => void;
    onChangeShowDeclaration: (_show: boolean, _event: GenericEvent | undefined, _properties: this) => void;
    onChangeState: (_state: ModelState, _event: GenericEvent | undefined, _properties: this) => void;
    onChangeValue: (_value: null | T, _event: GenericEvent | undefined, _properties: this) => void;
    onClick: (_event: MouseEvent, _properties: this) => void;
    onFocus: (_event: FocusEvent, _properties: this) => void;
    onTouch: (_event: GenericEvent, _properties: this) => void;
}
export declare type Properties<T = unknown> = TypedProperties<T> & CommonModel<T>;
export declare type Props<T = unknown> = Partial<Omit<Properties<T>, 'model'>> & {
    model?: Partial<Model<T>>;
};
export declare type DefaultProperties<T = unknown> = Omit<Props<T>, 'model'> & {
    model: Model<T>;
};
export interface State<T = unknown> {
    modelState?: ModelState;
    value?: null | T;
}
export interface ValueState<T = unknown, MS = ModelState> {
    modelState: MS;
    value: null | T;
}
export interface EditorState {
    editorIsActive: boolean;
    selectionIsUnstable: boolean;
}
export interface StaticWebComponent<MS = ModelState, DP = DefaultProperties> extends StaticBaseWebComponent {
    defaultModelState: MS;
    defaultProperties: DP;
    strict: boolean;
}
export declare type StaticComponent<P = Props, MS = ModelState, DP = DefaultProperties> = Omit<ComponentClass<P>, 'propTypes'> & StaticWebComponent<MS, DP>;
export declare type StaticFunctionComponent<P = Props, MS = ModelState, DP = DefaultProperties> = Omit<FunctionComponent<P>, 'propTypes'> & StaticComponent<P, MS, DP>;
export interface InputComponent<P = Props, MS = ModelState, DP = DefaultProperties, A = ComponentAdapter<P>> extends Omit<ForwardRefExoticComponent<P>, 'propTypes'>, StaticWebComponent<MS, DP> {
    (_props: P & RefAttributes<A>): ReactElement;
}
export declare const baseModelPropertyTypes: ValidationMapping;
export declare const modelStatePropertyTypes: {
    [_key in keyof ModelState]: Requireable<boolean | symbol>;
};
export declare const modelPropertyTypes: ValidationMapping;
export declare const propertyTypes: ValidationMapping;
export declare const defaultModelState: ModelState;
export declare const defaultModel: Model<string>;
export declare const defaultProperties: DefaultProperties<string>;
export interface CheckboxProperties extends Properties<boolean> {
    checked: boolean;
    id: string;
}
export declare type CheckboxModel = Model<boolean>;
export declare type CheckboxModelState = ModelState;
export declare type CheckboxValueState = ValueState<boolean, CheckboxModelState>;
export declare type CheckboxProps = Partial<Omit<CheckboxProperties, 'model'>> & {
    model?: Partial<CheckboxModel>;
};
export declare type DefaultCheckboxProperties = Omit<CheckboxProps, 'model'> & {
    model: CheckboxModel;
};
export declare type CheckboxState = State<boolean>;
export declare type CheckboxAdapter = ComponentAdapter<CheckboxProperties, Omit<CheckboxState, 'value'>>;
export declare type CheckboxComponent = InputComponent<CheckboxProps, CheckboxModelState, DefaultCheckboxProperties, CheckboxAdapter>;
export declare const checkboxPropertyTypes: PropertiesValidationMap;
export declare const defaultCheckboxModel: CheckboxModel;
export declare const defaultCheckboxProperties: DefaultCheckboxProperties;
export interface FormatSpecification<T = unknown> {
    options?: PlainObject;
    transform?: (_value: T, _configuration: DefaultInputProperties<T>, _transformer: InputDataTransformation) => string;
}
export interface DataTransformSpecification<T = unknown, InputType = number | string> {
    format?: {
        final: FormatSpecification<T>;
        intermediate?: FormatSpecification<T>;
    };
    parse?: (_value: InputType, _configuration: DefaultInputProperties<T>, _transformer: InputDataTransformation) => T;
    type?: NativeInputType;
}
export declare type InputDataTransformation = {
    boolean: DataTransformSpecification<boolean, number | string>;
    currency: DataTransformSpecification<number, string>;
    date: DataTransformSpecification<number, number | string>;
    'datetime-local': DataTransformSpecification<number, number | string>;
    time: DataTransformSpecification<number, number | string>;
    float: DataTransformSpecification<number, string>;
    integer: DataTransformSpecification<number, string>;
    number: DataTransformSpecification<number, number>;
    string?: DataTransformSpecification<unknown>;
} & {
    [_key in Exclude<NativeInputType, 'date' | 'datetime-local' | 'time' | 'number'>]?: DataTransformSpecification<unknown>;
};
export interface InputTablePosition {
    column: number;
    row: number;
}
export interface InputModelState extends ModelState {
    invalidMaximum: boolean;
    invalidMinimum: boolean;
    invalidMaximumLength: boolean;
    invalidMinimumLength: boolean;
    invalidInvertedPattern: boolean;
    invalidPattern: boolean;
}
export interface InputModel<T = unknown> extends Model<T> {
    state: InputModelState;
}
export interface InputValueState<T = unknown, MS = ModelState> extends ValueState<T, MS> {
    representation?: string;
}
export declare type NativeInputType = ('date' | 'datetime-local' | 'month' | 'number' | 'range' | 'text' | 'time' | 'week');
export declare type GenericInputType = ('boolean' | 'currency' | 'float' | 'integer' | 'string' | NativeInputType);
export interface InputChildrenOptions<P, T> {
    index: number;
    normalizedSelection: (SelectProps['options'] | Array<{
        label?: string;
        value: unknown;
    }>);
    properties: P;
    query: string;
    suggestion: string;
    value: T;
}
export interface SuggestionCreatorOptions<P> {
    abortController: AbortController;
    properties: P;
    query: string;
}
export interface InputProperties<T = unknown> extends InputModelState, Properties<T> {
    align: 'end' | 'start';
    children: (_options: InputChildrenOptions<this, T>) => null | ReactElement;
    cursor: CursorState;
    editor: ('code' | 'code(css)' | 'code(script)' | 'plain' | 'text' | 'richtext(raw)' | 'richtext(simple)' | 'richtext(normal)' | 'richtext(advanced)');
    editorIsActive: boolean;
    fullWidth: boolean;
    hidden: boolean;
    icon: string | (IconOptions & {
        tooltip?: string | TooltipProps;
    });
    inputProperties: Partial<CodeEditorProps | RichTextEditorProps | SelectProps | TextFieldProps>;
    invertedPatternText: string;
    labels: Array<string> | Mapping;
    maximumLengthText: string;
    maximumText: string;
    minimumLengthText: string;
    minimumText: string;
    model: InputModel<T>;
    onChangeEditorIsActive: (_isActive: boolean, _event: MouseEvent | undefined, _properties: this) => void;
    onKeyDown: (_event: KeyboardEvent, _properties: this) => void;
    onKeyUp: (_event: KeyboardEvent, _properties: this) => void;
    onSelect: (_event: GenericEvent, _properties: this) => void;
    onSelectionChange: (_event: GenericEvent, _properties: this) => void;
    outlined: boolean;
    patternText: string;
    placeholder: string;
    representation: string;
    rows: number;
    searchSelection: boolean;
    selectableEditor: boolean;
    step: number;
    suggestionCreator?: (_options: SuggestionCreatorOptions<this>) => InputProperties['selection'] | Promise<InputProperties['selection']>;
    suggestSelection: boolean;
    trailingIcon: string | (IconOptions & {
        tooltip?: string | TooltipProps;
    });
    transformer: RecursivePartial<DataTransformSpecification<T>>;
}
export declare type InputProps<T = unknown> = Partial<Omit<InputProperties<T>, 'model'>> & {
    model?: Partial<InputModel<T>>;
};
export declare type DefaultInputProperties<T = string> = Omit<InputProps<T>, 'model'> & {
    model: InputModel<T>;
};
export declare type InputPropertyTypes<T = unknown> = {
    [_key in keyof InputProperties<T>]: ValueOf<typeof PropertyTypes>;
};
export interface InputState<T = unknown> extends State<T> {
    cursor: CursorState;
    editorIsActive: boolean;
    hidden?: boolean;
    modelState: InputModelState;
    representation?: string;
    selectionIsUnstable: boolean;
    showDeclaration: boolean;
}
export declare type InputAdapter<T = unknown> = ComponentAdapter<InputProperties<T>, Omit<InputState<T>, 'representation' | 'selectionIsUnstable' | 'value'> & {
    representation?: string;
    value?: null | T;
}>;
export interface InputAdapterWithReferences<T = unknown> extends InputAdapter<T> {
    references: {
        codeEditorReference: MutableRefObject<CodeEditorType | null>;
        codeEditorInputReference: MutableRefObject<HTMLTextAreaElement | null>;
        foundationReference: MutableRefObject<MDCSelectFoundation | MDCTextFieldFoundation | null>;
        inputReference: MutableRefObject<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement | null>;
        richTextEditorInputReference: MutableRefObject<HTMLTextAreaElement | null>;
        richTextEditorInstance: MutableRefObject<RichTextEditor | null>;
        richTextEditorReference: MutableRefObject<RichTextEditorComponent | null>;
        suggestionMenuAPIReference: MutableRefObject<MenuApi | null>;
        suggestionMenuFoundationReference: MutableRefObject<MDCMenuFoundation | null>;
    };
}
export interface TinyMCEOptions extends RawTinyMCEOptions {
    selector?: undefined;
    target?: undefined;
}
export interface GenericInputComponent extends Omit<ForwardRefExoticComponent<InputProps>, 'propTypes'>, StaticWebComponent<InputModelState, DefaultInputProperties> {
    <T = string>(_props: InputProps<T> & RefAttributes<InputAdapter<T>>): ReactElement;
    locales: Array<string>;
    transformer: InputDataTransformation;
}
export declare const inputModelStatePropertyTypes: {
    [_key in keyof InputModelState]: Requireable<boolean | symbol>;
};
export declare const inputPropertyTypes: PropertiesValidationMap;
export declare const inputRenderProperties: Array<string>;
export declare const defaultInputModelState: InputModelState;
export declare const defaultInputModel: InputModel<string>;
export declare const defaultInputProperties: DefaultInputProperties;
export declare type FileRepresentationType = 'binary' | 'image' | 'renderableText' | 'text' | 'video';
export interface FileValue {
    blob?: Partial<Blob> | null;
    hash?: null | string;
    name?: null | string;
    source?: null | string;
    url?: null | string;
}
export interface FileInputValueState extends ValueState<FileValue, FileInputModelState> {
    attachBlobProperty: boolean;
}
export interface FileInputModelState extends ModelState {
    invalidMaximumSize: boolean;
    invalidMinimumSize: boolean;
    invalidContentTypePattern: boolean;
    invalidName: boolean;
}
export interface FileInputModel extends Model<FileValue> {
    contentTypeRegularExpressionPattern: Array<RegExp | string> | null | RegExp | string;
    invertedContentTypeRegularExpressionPattern: (Array<RegExp | string> | null | RegExp | string);
    maximumSize: number;
    minimumSize: number;
    fileName: InputModel<string>;
    state: FileInputModelState;
}
export interface FileInputChildrenOptions<P> {
    declaration: string;
    invalid: boolean;
    properties: P;
    value?: FileValue | null;
}
export interface FileInputProperties extends Properties<FileValue>, FileInputModelState {
    children: (_options: FileInputChildrenOptions<this>) => null | ReactElement;
    contentTypePattern: Array<RegExp | string> | null | RegExp | string;
    invertedContentTypePattern: Array<RegExp | string> | null | RegExp | string;
    contentTypePatternText: string;
    invertedContentTypePatternText: string;
    maximumSizeText: string;
    minimumSizeText: string;
    deleteButton: ReactElement | string;
    downloadButton: ReactElement | string;
    editButton: ReactElement | string;
    newButton: ReactElement | string;
    encoding: string;
    generateFileNameInputProperties: (_prototype: InputProps<string>, _properties: this & {
        value: FileValue & {
            name: string;
        };
    }) => InputProps<string>;
    media: CardMediaProps;
    model: FileInputModel;
    outlined: boolean;
    sourceToBlobOptions: {
        endings?: 'native' | 'transparent';
        type?: string;
    };
}
export declare type FileInputProps = Partial<Omit<FileInputProperties, 'model'>> & {
    model?: Partial<FileInputModel>;
};
export declare type DefaultFileInputProperties = Omit<FileInputProps, 'model'> & {
    model: FileInputModel;
};
export declare type FileInputPropertyTypes = {
    [_key in keyof FileInputProperties]: ValueOf<typeof PropertyTypes>;
};
export interface FileInputState extends State<FileValue> {
    modelState: FileInputModelState;
}
export declare type FileInputAdapter = ComponentAdapter<FileInputProperties, Omit<FileInputState, 'value'> & {
    value?: FileValue | null;
}>;
export interface FileInputAdapterWithReferences extends FileInputAdapter {
    references: {
        deleteButtonReference: MutableRefObject<HTMLButtonElement | null>;
        downloadLinkReference: MutableRefObject<HTMLAnchorElement | null>;
        fileInputReference: MutableRefObject<HTMLInputElement | null>;
        nameInputReference: MutableRefObject<InputAdapter<string> | null>;
        uploadButtonReference: MutableRefObject<HTMLButtonElement | null>;
    };
}
export declare type FileInputComponent = InputComponent<FileInputProps, FileInputModelState, DefaultFileInputProperties, FileInputAdapter>;
export declare const fileInputModelStatePropertyTypes: {
    [_key in keyof FileInputModelState]: Requireable<boolean | symbol>;
};
export declare const fileInputPropertyTypes: PropertiesValidationMap;
export declare const defaultFileInputModelState: FileInputModelState;
export declare const defaultFileInputModel: FileInputModel;
export declare const defaultFileNameInputProperties: InputProps<string>;
export declare const defaultFileInputProperties: DefaultFileInputProperties;
export interface InputsPropertiesItem<T, TS = unknown> {
    model?: {
        state?: TS;
        value?: null | T;
    };
    value?: null | T;
}
export interface InputsCreatePrototypeOptions<T, P extends InputsPropertiesItem<T>, IP> {
    index: number;
    properties: IP;
    prototype: Partial<P>;
    values: Array<null | T | undefined> | null;
}
export interface InputsModelState extends ModelState {
    invalidMaximumNumber: boolean;
    invalidMinimumNumber: boolean;
}
export interface InputsModel<T, P extends InputsPropertiesItem<T>> extends Model<Array<P>> {
    maximumNumber: number;
    minimumNumber: number;
    state: InputsModelState;
    writable: boolean;
}
export interface InputsChildrenOptions<T, P extends InputsPropertiesItem<T>, IP> {
    index: number;
    inputsProperties: IP;
    properties: Partial<P>;
}
export interface InputsProperties<T = unknown, P extends InputsPropertiesItem<T> = Properties<T>> extends InputsModelState, Omit<Properties<Array<P>>, 'onChangeValue'> {
    addIcon: IconOptions;
    removeIcon: IconOptions;
    children: (_options: InputsChildrenOptions<T, P, this>) => ReactElement;
    createPrototype: (_options: InputsCreatePrototypeOptions<T, P, this>) => P;
    maximumNumber: number;
    minimumNumber: number;
    model: InputsModel<T, P>;
    onChangeValue: (_values: Array<null | T> | null, _event: GenericEvent | unknown, _properties: this) => void;
    value: Array<P> | null;
    writable: boolean;
}
export declare type InputsProps<T = unknown, P extends InputsPropertiesItem<T> = Properties<T>> = Partial<Omit<InputsProperties<T, P>, 'model' | 'value'>> & {
    model?: Partial<InputsModel<T, P>>;
    value?: Array<Partial<P>> | Array<null | T | undefined> | null;
};
export declare type DefaultInputsProperties<T = string, P extends InputsPropertiesItem<T> = InputProps<T>> = Partial<Omit<InputsProperties<T, P>, 'default' | 'model' | 'value'>> & {
    model: InputsModel<T, P>;
};
export declare type InputsPropertyTypes<T = unknown, P extends InputsPropertiesItem<T> = Properties<T>> = {
    [_key in keyof InputsProperties<P>]: ValueOf<typeof PropertyTypes>;
};
export declare type InputsState<T = unknown> = State<Array<null | T | undefined>>;
export declare type InputsAdapter<T = unknown, P extends InputsPropertiesItem<T> = Properties<T>> = ComponentAdapter<InputsProperties<T, P>, InputsState<T>>;
export declare type InputsAdapterWithReferences<T = unknown, P extends InputsPropertiesItem<T> = Properties<T>, RefType = unknown> = InputsAdapter<T, P> & {
    references: Array<MutableRefObject<RefType>>;
};
export interface InputsComponent extends Omit<ForwardRefExoticComponent<InputsProps>, 'propTypes'>, StaticWebComponent<InputsModelState, DefaultInputsProperties> {
    <T = string, P extends InputsPropertiesItem<T> = InputProperties<T>>(_props: InputsProps<T, P> & RefAttributes<InputsAdapter<T, P>>): ReactElement;
}
export declare const inputsPropertyTypes: PropertiesValidationMap;
export declare const inputsRenderProperties: Array<string>;
export declare const defaultInputsModel: InputsModel<string, InputProperties<string>>;
export declare const defaultInputsProperties: DefaultInputsProperties;
export interface IntervalValue {
    end?: null | number;
    start?: null | number;
}
export interface IntervalConfiguration {
    end: InputProps<number>;
    start: InputProps<number>;
}
export declare type IntervalModelState = ModelState;
export interface IntervalModel {
    name: string;
    state: IntervalModelState;
    value: {
        end: InputModel<number>;
        start: InputModel<number>;
    };
}
export interface IntervalProperties extends Omit<InputProperties<number>, 'icon' | 'model' | 'onChange' | 'onChangeValue' | 'value'> {
    icon: IconOptions;
    model: IntervalModel;
    onChange: (_properties: this, _event?: GenericEvent) => void;
    onChangeValue: (_value: null | IntervalValue, _event?: GenericEvent) => void;
    value: IntervalConfiguration;
}
export declare type IntervalProps = Omit<InputProps<number>, 'icon' | 'model' | 'onChange' | 'onChangeValue' | 'value'> & Partial<{
    end: InputProps<number>;
    start: InputProps<number>;
    icon: IntervalProperties['icon'];
    model: IntervalProperties['model'];
    onChange: IntervalProperties['onChange'];
    onChangeValue: IntervalProperties['onChangeValue'];
    value: IntervalConfiguration | IntervalValue | null;
}>;
export declare type DefaultIntervalProperties = Omit<IntervalProps, 'model'> & {
    model: IntervalModel;
};
export declare type IntervalPropertyTypes = {
    [_key in keyof IntervalProperties]: ValueOf<typeof PropertyTypes>;
};
export declare type IntervalAdapter = ComponentAdapter<IntervalProperties, {
    value?: IntervalValue | null;
}>;
export interface IntervalAdapterWithReferences extends IntervalAdapter {
    references: {
        end: MutableRefObject<InputAdapterWithReferences<number> | null>;
        start: MutableRefObject<InputAdapterWithReferences<number> | null>;
    };
}
export declare type IntervalComponent = InputComponent<IntervalProps, IntervalModelState, DefaultIntervalProperties, IntervalAdapter>;
export declare const intervalPropertyTypes: PropertiesValidationMap;
export declare const defaultIntervalProperties: DefaultIntervalProperties;
export interface ConfigurationProperties {
    strict?: boolean;
    themeConfiguration?: ThemeProviderProps['options'];
    tooltip?: Properties['tooltip'];
    wrap?: boolean;
}
