import { NullSymbol, UndefinedSymbol } from 'clientnode/property-types';
import { Mapping } from 'clientnode/type';
import { useState } from 'react';
import { SelectProps } from '@rmwc/select';
import { BaseProperties, BaseProps, DefaultBaseProperties, DefaultInputProperties, InputDataTransformation, ModelState, ValueState } from './type';
/**
 * Creates a mocked a state setter. Useful to dynamically convert a component
 * from uncontrolled to controlled.
 * @param value - Parameter for state setter.
 *
 * @returns Nothing.
 */
export declare const createDummyStateSetter: <Type = unknown>(value: Type) => ReturnType<typeof useState>[1];
/**
 * Consolidates properties not found in properties but in state into
 * properties.
 * @param properties - To consolidate.
 * @param state - To search values in.
 *
 * @returns Consolidated properties.
 */
export declare const deriveMissingPropertiesFromState: <Properties extends BaseProps = BaseProps, State extends ValueState<unknown, ModelState> = ValueState<unknown, ModelState>>(properties: Properties, state: State) => Properties;
/**
 * Creates a hybrid a state setter wich only triggers when model state changes
 * occur. Useful to dynamically convert a component from uncontrolled to
 * controlled while model state should be uncontrolled either.
 * @param setValueState - Value setter to wrap.
 * @param currentValueState - Last known value state to provide to setter when
 * called.
 *
 * @returns Wrapped given method.
 */
export declare const wrapStateSetter: <Type = unknown>(setValueState: (_value: Type | ((_value: Type) => Type)) => void, currentValueState: Type) => ReturnType<typeof useState>[1];
/**
 * Triggered when a value state changes like validation or focusing.
 * @param properties - Properties to search in.
 * @param name - Event callback name to search for in given properties.
 * @param synchronous - Indicates whether to trigger callback immediately or
 * later. Controlled components should call synchronously and uncontrolled
 * otherwise as long as callbacks are called in a state setter context.
 * @param parameters - Additional arguments to forward to callback.
 *
 * @returns Nothing.
 */
export declare const triggerCallbackIfExists: <P extends Omit<BaseProperties, "model"> & {
    model: unknown;
}>(properties: P, name: string, synchronous?: boolean, ...parameters: Array<unknown>) => void;
/**
 * Translate known symbols in a copied and return properties object.
 * @param properties - Object to translate.
 *
 * @returns Transformed properties.
 */
export declare const translateKnownSymbols: <Type = unknown>(properties: Mapping<typeof NullSymbol | typeof UndefinedSymbol | Type>) => Mapping<Type>;
/**
 * Determines initial value depending on given properties.
 * @param properties - Components properties.
 * @param defaultValue - Internal fallback value.
 * @param alternateValue - Alternate value to respect.
 *
 * @returns Determined value.
 */
export declare const determineInitialValue: <Type = unknown>(properties: BaseProps, defaultValue?: Type | null | undefined, alternateValue?: Type | null | undefined) => Type | null;
/**
 * Derives current validation state from given value.
 * @param properties - Input configuration.
 * @param currentState - Current validation state.
 * @param validators - Mapping from validation state key to corresponding
 * validator function.
 *
 * @returns A boolean indicating if validation state has changed.
 */
export declare const determineValidationState: <P extends DefaultBaseProperties = DefaultBaseProperties, MS extends Partial<ModelState> = Partial<ModelState>>(properties: P, currentState: MS, validators?: Mapping<() => boolean>) => boolean;
/**
 * Synchronizes property, state and model configuration:
 * Properties overwrites default properties which overwrites default model
 * properties.
 * @param properties - Properties to merge.
 * @param defaultModel - Default model to merge.
 *
 * @returns Merged properties.
*/
export declare const mapPropertiesIntoModel: <P extends BaseProps = BaseProps, DP extends DefaultBaseProperties = DefaultBaseProperties>(properties: P, defaultModel: DP["model"]) => DP;
/**
 * Calculate external properties (a set of all configurable properties).
 * @param properties - Properties to merge.
 *
 * @returns External properties object.
 */
export declare const getConsolidatedProperties: <P extends BaseProps, R extends BaseProperties>(properties: P) => R;
/**
 * Determine normalized labels and values for selection and auto-complete
 * components.
 * @param selection - Selection component property configuration.
 *
 * @returns Normalized sorted listed of labels and values.
 */
export declare function getLabelAndValues(selection?: SelectProps['options'] | Array<{
    label?: string;
    value: unknown;
}>): [Array<string>, Array<unknown>];
/**
 * Determine representation for given value while respecting existing labels.
 * @param value - To represent.
 * @param selection - Selection component property configuration.
 *
 * @returns Determined representation.
 */
export declare function getRepresentationFromValueSelection(value: unknown, selection?: SelectProps['options'] | Array<{
    label?: string;
    value: unknown;
}>): null | string;
/**
 * Determine value from provided representation (for example user inputs).
 * @param label - To search a value for.
 * @param selection - Selection component property configuration.
 *
 * @returns Determined value.
 */
export declare function getValueFromSelection<T>(label: string, selection: SelectProps['options'] | Array<{
    label?: string;
    value: unknown;
}>): null | T;
/**
 * Normalize given selection.
 * @param selection - Selection component property configuration.
 * @param labels - Additional labels to take into account (for example provided
 * via a content management system).
 *
 * @returns Determined normalized selection configuration.
 */
export declare function normalizeSelection(selection?: (Array<[string, string]> | SelectProps['options'] | Array<{
    label?: string;
    value: unknown;
}>), labels?: Array<string> | Mapping): SelectProps['options'] | Array<{
    label?: string;
    value: unknown;
}> | undefined;
/**
 * Applies configured value transformations.
 * @param configuration - Input configuration.
 * @param value - Value to transform.
 * @param transformer - To apply to given value.
 *
 * @returns Transformed value.
 */
export declare const parseValue: <T = unknown, P extends DefaultInputProperties<T> = DefaultInputProperties<T>, InputType = T>(configuration: P, value: InputType | null, transformer: InputDataTransformation) => T | null;
/**
 * Represents configured value as string.
 * @param configuration - Input configuration.
 * @param value - To represent.
 * @param transformer - To apply to given value.
 * @param final - Specifies whether it is a final representation.
 *
 * @returns Transformed value.
 */
export declare function formatValue<T = unknown, P extends DefaultInputProperties<T> = DefaultInputProperties<T>>(configuration: P, value: null | T, transformer: InputDataTransformation, final?: boolean): string;
/**
 * Determines initial value representation as string.
 * @param properties - Components properties.
 * @param defaultProperties - Components default properties.
 * @param value - Current value to represent.
 * @param transformer - To apply to given value.
 * @param selection - Data mapping of allowed values.
 *
 * @returns Determined initial representation.
 */
export declare function determineInitialRepresentation<T = unknown, P extends DefaultInputProperties<T> = DefaultInputProperties<T>>(properties: P, defaultProperties: P, value: null | T, transformer: InputDataTransformation, selection?: SelectProps['options'] | Array<{
    label?: string;
    value: unknown;
}>): string;
/**
 * Custom hook to memorize any values with a default empty array. Useful if
 * using previous constant complex object within a render function.
 * @param value - Value to memorize.
 * @param dependencies - Optional dependencies when to update given value.
 *
 * @returns Given cached value.
 */
export declare const useMemorizedValue: <T = unknown>(value: T, ...dependencies: Array<unknown>) => T;
